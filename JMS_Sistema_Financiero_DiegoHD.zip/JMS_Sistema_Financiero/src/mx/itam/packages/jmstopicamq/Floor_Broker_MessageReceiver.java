/**
 * @author Diego Hernández Delgado
 * @CU 176262
 * Fecha: 16/03/2022
 * Práctica JMS Queues Financiero
 */

package mx.itam.packages.jmstopicamq;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Floor_Broker_MessageReceiver extends Thread {

    // URL of the JMS server
    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    // default broker URL is : tcp://localhost:61616"

    // Name of the topic we will receive messages from
    private  String subject = "JOGG_TOPIC";


    public Floor_Broker_MessageReceiver(String subject){
        this.subject = subject;
    }


    @Override
    public void run() {

        boolean goodByeReceived = false;
        String msg = "";
        int risk;

        try {
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);

            Destination destination = session.createTopic(subject);

            MessageConsumer messageConsumer = session.createConsumer(destination);

            while (!goodByeReceived) {
                System.out.println( ".............................");
                TextMessage textMessage = (TextMessage) messageConsumer.receive();
                if (textMessage != null) {
                    msg = textMessage.getText();
                    System.out.println("BROKER " + msg);

                    risk = Character.getNumericValue( msg.charAt(msg.length()-1) );

                    if(risk < 5){
                        System.out.print( "   Risk is LOW, let's HOLD to the moon! ");
                    }else{
                        System.out.print( "   Risk is HIGH, let's SELL ASAP! ");
                    }
                    System.out.println();
                }

                if (textMessage.getText() != null && textMessage.getText().equals("FIN"))
                    goodByeReceived = true;

            }

            messageConsumer.close();
            session.close();
            connection.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

}