/**
 * @author Diego Hernández Delgado
 * @CU 176262
 * Fecha: 16/03/2022
 * Práctica JMS Sistema Financiero (Queues)
 */

package mx.itam.packages.jmstopicamq;

public class Deployer {

    public static void main(String [] args) {
        String [] subjects = {"FOREX", "PETROLEUM", "CRYPTO", "COMMODITIES", "TECH"};

        for(int i=0; i<5; i++){
            new Floor_Broker_MessageReceiver(subjects[i]).start(); //El start te permite correrlo concurrentemente, en vez de en un solo hilo.
        }

    }
}
