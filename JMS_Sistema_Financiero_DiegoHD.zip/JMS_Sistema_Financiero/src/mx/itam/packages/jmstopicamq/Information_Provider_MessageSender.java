/**
 * @author Diego Hernández Delgado
 * @CU 176262
 * Fecha: 16/03/2022
 * Práctica JMS Sistema Financiero (Queues)
 */

package mx.itam.packages.jmstopicamq;

import javax.jms.*;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.jetbrains.annotations.NotNull;

public class Information_Provider_MessageSender {

    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL; // default broker URL is : tcp://localhost:61616"

    private static String subject = "";
    private static String [] subjects = {"FOREX", "PETROLEUM", "CRYPTO", "COMMODITIES", "TECH"};
    private static int min, i = 0;
    private static int max = 5;
    private String msg = "";
    private int random_number, risk;


    public void produceMessages() {

        try {

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);

            //Levantar tópicos y enviar mensaje al respecto
            for(i = 0; i <50 ; i++){


                //Pick a topic
                random_number = (int) (Math.random() * 5) ;
                subject = subjects[random_number];

                //Generate random risk
                risk = (int) (Math.random()*11);

                //Write message
                msg = subject + " INFO --> " + "risk: " + Integer.toString(risk);

                //Create topic and send message
                produceSessionAndMessage(session, subject, msg);
            }

            //Mensaje para terminar/apagar a los receivers Floor_Broker_Message_Receiver
            for(i = 0; i <5 ; i++){
                subject = subjects[i];
                msg = subject +" --> FIN !!!!!!!";
                produceSessionAndMessage(session, subject, msg);
            }

            //Close session and connection
            session.close();
            connection.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public void produceSessionAndMessage(@NotNull Session session, String subject, String msg){

        try {
            Topic destination = session.createTopic(subject);
            MessageProducer messageProducer = session.createProducer(destination);
            TextMessage textMessage = session.createTextMessage();

            textMessage.setText(msg);
            System.out.println("Message: " + textMessage.getText());
            messageProducer.send(textMessage);

            messageProducer.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        new Information_Provider_MessageSender().produceMessages();
    }
}
