from django.contrib import admin
from .models import Pensionado

# Register your models here.
admin.site.register(Pensionado)