package estres;

public class Globals {
    public static boolean debug=true;
    public static int topos=9;
    public static int points_2_win=2;
}
