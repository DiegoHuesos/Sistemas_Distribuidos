/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estres;

/**
 *
 * @author padillandrea
 */
public class Globals {
    public static boolean debugMode = true;
    public static int topos = 9;
    public static int point_to_win = 3;
}
