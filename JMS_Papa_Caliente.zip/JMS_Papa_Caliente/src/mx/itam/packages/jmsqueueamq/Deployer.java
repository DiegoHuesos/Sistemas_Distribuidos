package mx.itam.packages.jmsqueueamq;

public class Deployer {

    public static void main(String[] args){
        Player jug1=new Player("Jugador 1","Jugador 2");
        Player jug2=new Player("Jugador 2","Jugador 1");

        jug1.start();
        jug2.start();
    }
}
