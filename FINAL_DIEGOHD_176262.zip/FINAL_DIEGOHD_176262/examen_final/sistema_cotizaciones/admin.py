from django.contrib import admin
from .models import Cliente, Auto
# Register your models here.
admin.site.register(Cliente)
admin.site.register(Auto)